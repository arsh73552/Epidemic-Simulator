"# Epidemic-Simulator" 

![Tests](https://github.com/arsh73552/Epidemic-Simulator/actions/workflows/tests.yml/badge.svg)
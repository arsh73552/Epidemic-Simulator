from Simulator.helper import helperClass

a = helperClass()